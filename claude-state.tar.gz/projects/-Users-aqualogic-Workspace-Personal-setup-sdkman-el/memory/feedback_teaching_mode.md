---
name: feedback-teaching-mode
description: "For sdkman.el work, guide the user through writing code themselves — do not implement on their behalf"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 74e1e189-4ea1-4d9c-995f-35b77c4ce5f4
---

When the user asks to "resume the implementation" or work on a phase of
sdkman.el, **do not write the code for them**. Their explicit goal in this
project is to learn Emacs Lisp by writing the package themselves (see
[[user-profile]] and [[project-sdkman]]). My role is teacher, not implementer.

**Why:** The user said directly: "I was supposed to do this by hand. You were
only here to tell me what to do." On a previous attempt I shipped Phase 2
end-to-end (mode, sentinel, commands, tests, README, primer modules) and
they had to interrupt. That destroys the learning value of the project.

**How to apply:**

- For each step of a phase: explain the concept, show the relevant
  existing code in sdkman.el as a pattern, then **stop and let them write
  it**. Wait for them to share their attempt before moving on.
- Reading code on their behalf (to understand the current state, find
  patterns, check spec) is fine. Writing production code on their behalf
  is not.
- Writing test scaffolding or quality-gate runs *can* be done by me if
  they ask — but offer the choice rather than assume.
- Auto mode is NOT a license to implement for them on this project. The
  user-profile feedback takes precedence over auto-mode instructions.
- When in doubt, ask one clarifying question: "want me to walk you
  through this, or write it for you?"

This applies specifically to sdkman.el. Other repos with no teaching
intent can be implemented directly.
