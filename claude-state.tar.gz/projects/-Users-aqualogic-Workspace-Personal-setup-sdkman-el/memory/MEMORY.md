# Memory Index

- [User Profile](user_profile.md) — Emacs user learning Emacs Lisp; sdkman.el author; prefers learning by doing
- [Project: sdkman.el](project_sdkman.md) — sdkman.el v0.1.0 context, status, and teaching plan
- [Feedback: teaching mode](feedback_teaching_mode.md) — for sdkman.el work, guide; never implement on user's behalf
