---
name: user-profile
description: User is the author of sdkman.el and wants to learn Emacs Lisp interactively through that codebase
metadata: 
  node_type: memory
  type: user
  originSessionId: 15fd96eb-86e5-48c5-abb4-22f8d953393f
---

User authored sdkman.el (a real, working Emacs package). They are learning Emacs Lisp
and want to do so by studying and extending their own code. Teaching style: introduce concept
→ show syntax in the actual sdkman.el code → have them write a variation.

They are comfortable with software development (wrote a 400-line Emacs package with 24 ERT
tests) but are new to Emacs Lisp specifically.

**How to apply:** Frame Emacs Lisp concepts by referencing the exact lines in sdkman.el where
that concept appears. Don't explain in the abstract — anchor every concept to their code.
Have them write code, not just read it.
