---
name: project-sdkman
description: "sdkman.el v0.1.0 status, architecture, and active teaching plan through 20 Emacs Lisp modules"
metadata: 
  node_type: memory
  type: project
  originSessionId: 15fd96eb-86e5-48c5-abb4-22f8d953393f
---

sdkman.el v0.1.0 — reads `.sdkmanrc`, applies SDKMAN candidates as buffer-local environments.
397 lines, 24 ERT tests. Status: V1 core done (discovery, env application, minor modes,
lsp-java). Pending: transient UI, sdk CLI wrapper (see docs/v1-plan.md).

Active teaching plan: 20 modules teaching Emacs Lisp concepts anchored to sdkman.el code.
Plan file: `/Users/aqualogic/.claude/plans/load-the-context-related-graceful-fountain.md`

**Why:** User wants to learn Emacs Lisp while working on their own package.
**How to apply:** Each session picks up from the last completed module. Check which module
was last completed before starting a new session.

Module progress (update as completed):
- [x] 1+2: S-expressions, defvar, defgroup
- [x] 3: defcustom
- [x] 4: defun & &optional
- [x] 5+6: let/let* + when/cond
- [x] 7+8: when-let + alists
- [x] 9+10: push/nreverse + dolist
- [x] 11: String operations
- [x] 12: File system operations
- [x] 13+14: setq-local + getenv/setenv
- [x] 15: cl-loop
- [x] 16: catch/throw
- [x] 17: with-temp-buffer
- [x] 18+19: define-minor-mode + globalized mode + hooks
- [x] 20: provide and autoload

Tutorial published to docs/elisp-primer.md. CONTRIBUTING.md updated with workflow.

## V1 implementation progress (Phase 0 + 1)

Active plan: `/Users/aqualogic/.claude/plans/let-s-start-with-phase-lazy-bubble.md`

Phase 0: COMPLETE (29 tests, byte-compile + checkdoc green)
- [x] P0-1: Expanded `sdkman-known-env-vars` (ant, groovy, spark, hadoop, micronaut, activemq; dropped kotlin)
- [x] P0-2: `sdkman--ensure-root` + wired into `sdkman-apply-buffer-env`
- [x] P0-3: `sdkman--init-script` + `sdkman--run-sdk-async`
- [x] P0-4: 5 tests (whitespace parser, ensure-root x2, init-script x2)

Phase 1: COMPLETE — released as v0.2.0 (commit e466158)
- All four transient bindings shipped: o, e, i, q
- 39 tests, byte-compile + checkdoc clean
- README documents the transient menu and current API
- Tag v0.1.0 corrected onto dcaf322 (original release commit)

Phase 2: IN PROGRESS on branch `phase2` (uncommitted)
Active plan: `/Users/aqualogic/.claude/plans/resume-the-implementation-and-melodic-kahn.md`
Working through it as a guided learning exercise — user writes the code, I teach
and review per [[feedback-teaching-mode]].

- [x] Step 1: `sdkman-process-mode` (define-derived-mode from compilation-mode,
      lighter "SDKMAN", :group 'sdkman)
- [x] Step 2: `sdkman--process-sentinel` (silent on success, message on
      non-zero exit using process-name + string-trim event)
- [ ] Step 3: `sdkman--run-cli` helper + `sdkman-sdk-list` + `sdkman-sdk-current`
      (NEXT — resume here)
- [ ] Step 4: transient L/C bindings + version bump to 0.3.0
- [ ] Step 5: tests (stub bash pattern, sentinel, ensure-root error path)
- [ ] Step 6: README + elisp-primer.md modules 21-24
- [ ] Step 7: commit + tag v0.3.0

Old changes from the auto-run attempt are stashed (see `git stash list`).

## How to resume Phase 2 next session

1. Check branch: should be on `phase2` with Steps 1+2 already written in
   sdkman.el (lines ~527-541 — sdkman-process-mode + sdkman--process-sentinel).
2. Run quality gate to confirm clean state:
   `emacs --batch -Q -L . -f batch-byte-compile sdkman.el && rm -f sdkman.elc`
3. Pick up at Step 3a — the `sdkman--run-cli` helper. Full task in the plan
   file. Teach by reference to existing patterns in `sdkman-show-env`
   (sdkman.el:491) and `sdkman-show-installed` (sdkman.el:507).
