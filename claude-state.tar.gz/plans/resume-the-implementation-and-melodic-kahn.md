# Resume implementation + learning: Phase 2 (read-only `sdk` CLI passthrough)

## Context

`sdkman.el` v0.2.0 shipped Phase 1 (transient skeleton + read-only actions
`o`/`e`/`i`/`q`). The Phase 0 foundation also added `sdkman--ensure-root`,
`sdkman--init-script`, and the async runner `sdkman--run-sdk-async`
(sdkman.el:142-181) — but no command actually calls the runner yet. Phase 2
wires the runner into the transient for the two `sdk` subcommands that don't
mutate global state: `sdk list <sdk>` and `sdk current`. After this phase the
package can drive real SDKMAN queries from inside Emacs.

In parallel with implementation, the user wants to extend the Emacs Lisp
primer (docs/elisp-primer.md). Phase 2 introduces four concepts the existing
20-module primer doesn't cover:
- `define-derived-mode` — first derived mode in the package
- process sentinels — async-completion callbacks
- `cl-letf` — function-binding stubs for tests
- `accept-process-output` — synchronizing tests with async processes

Teach inline during implementation **and** append modules 21–24 to the primer
at the end. Tag `v0.3.0` once the quality gate is green.

## Progress (as of 2026-05-25)

Branch: `phase2` (uncommitted). Working through this as guided learning per
[[feedback-teaching-mode]] — user writes the code, assistant teaches and
reviews.

- [x] Step 1: `sdkman-process-mode` (define-derived-mode from
      compilation-mode, lighter "SDKMAN", :group 'sdkman)
- [x] Step 2: `sdkman--process-sentinel` (silent on success, message on
      non-zero exit using process-name + string-trim event)
- [x] Step 3: `sdkman--run-cli` helper + `sdkman-sdk-list` +
      `sdkman-sdk-current` (verified interactively against real SDKMAN —
      `sdk current` and `sdk list java` both produce expected output)
- [x] Phase 0 tweak: `sdkman--run-sdk-async` now prefixes `PAGER=cat`
      so SDKMAN's `less` doesn't engage in a non-TTY buffer (discovered
      during Step 3b smoke test — "WARNING: terminal is not fully
      functional" appeared otherwise)
- [ ] **Step 4 (next): transient L/C bindings + version bump to 0.3.0**
- [ ] Step 5: tests (4 sub-steps — see Step 5 section below)
- [ ] Step 6: README updates
- [ ] Step 7: primer modules 21-24
- [ ] Step 8: commit + tag v0.3.0

Quality gate is currently green: byte-compile silent, checkdoc silent,
39 existing tests pass.

## Approach

### Step 1 — `sdkman-process-mode` (sdkman.el, new section before transient)

Add a minimal derived mode. `compilation-mode` parent gives us `q` to bury,
`n`/`p` for next/previous error, font-locking, and a read-only buffer:

```elisp
(define-derived-mode sdkman-process-mode compilation-mode "SDKMAN"
  "Major mode for SDKMAN async process output buffers.")
```

**Teach inline:** `define-derived-mode` syntax (child, parent, mode-line tag,
docstring). Show that the new mode inherits the parent keymap — no need to
re-implement `q`.

### Step 2 — Output sentinel helper (sdkman.el)

One shared sentinel for both new commands. On success: nothing extra (the
output is already in the buffer). On non-zero exit: `message` the exit
status and leave the buffer visible:

```elisp
(defun sdkman--process-sentinel (process event)
  "Sentinel for SDKMAN async processes.
Show exit status when PROCESS terminates with non-zero status.
EVENT is the standard process-state-change string."
  (when (memq (process-status process) '(exit signal))
    (let ((code (process-exit-status process))
          (buf  (process-buffer process)))
      (when (and (/= code 0) (buffer-live-p buf))
        (message "sdkman: %s exited %d (%s)"
                 (process-name process) code (string-trim event))))))
```

**Teach inline:** sentinel signature `(process event)`; `process-status` vs
`process-exit-status`; why `event` is a string like `"finished\n"`; why we
check `buffer-live-p` (the user can kill the buffer mid-run).

### Step 3 — `sdkman-sdk-list` and `sdkman-sdk-current` commands

Mirror the style of `sdkman-show-installed` (sdkman.el:507-525):

```elisp
;;;###autoload
(defun sdkman-sdk-list (sdk)
  "Run `sdk list SDK' asynchronously into *sdkman: list*."
  (interactive
   (list (completing-read
          "SDK: "
          (directory-files
           (expand-file-name "candidates" (sdkman--ensure-root))
           nil "\\`[^.]"))))
  (sdkman--run-cli "list" (list sdk) (format "*sdkman: list %s*" sdk)))

;;;###autoload
(defun sdkman-sdk-current ()
  "Run `sdk current' asynchronously into *sdkman: current*."
  (interactive)
  (sdkman--ensure-root)
  (sdkman--run-cli "current" nil "*sdkman: current*"))
```

Factor the boilerplate (buffer setup → header line → spawn → pop-to-buffer)
into one private helper to keep the two commands trivial:

```elisp
(defun sdkman--run-cli (subcommand args buffer-name)
  "Spawn `sdk SUBCOMMAND ARGS' into BUFFER-NAME and display it."
  (let ((buf (get-buffer-create buffer-name)))
    (with-current-buffer buf
      (let ((inhibit-read-only t))
        (erase-buffer)
        (insert (format "$ sdk %s %s\n\n"
                        subcommand (string-join args " "))))
      (sdkman-process-mode))
    (sdkman--run-sdk-async subcommand args buf #'sdkman--process-sentinel)
    (pop-to-buffer buf)))
```

Note: `sdkman-sdk-list` uses `sdkman--ensure-root` (explicit, signals
`user-error` if SDKMAN missing) instead of `sdkman--default-root` — this
plugs the gap where the existing `sdkman-show-installed` would silently try
to list an empty `candidates/`.

### Step 4 — Transient bindings (sdkman.el:527-535)

Add an "SDKMAN CLI" group below the existing read-only group:

```elisp
(transient-define-prefix sdkman ()
  "SDKMAN project menu."
  [:description
   (lambda () (string-join (sdkman--status-lines) "\n"))
   ["Project"
    ("o" "Open .sdkmanrc"           sdkman-open-sdkmanrc)
    ("e" "Show SDKMAN environment"  sdkman-show-env)
    ("i" "Show installed candidates" sdkman-show-installed)]
   ["SDKMAN CLI"
    ("L" "List candidates" sdkman-sdk-list)
    ("C" "Show current"    sdkman-sdk-current)]
   [("q" "Quit" transient-quit-one)]])

```

### Step 5 — Tests (test/sdkman-test.el) — NEXT

Done as guided learning, in this order. Each sub-step introduces one new
testing idea; user writes the test, assistant points at patterns in the
existing test file to mirror. **No pre-written test code in this plan** —
the test design IS the learning.

#### 5a — Sentinel error-path test (easiest; doesn't need a process)

`sdkman--process-sentinel` is a pure callback — `(process event)` →
side effect via `message`. To test it, fake a process object and verify
the `message` call.

- **New concept:** `cl-letf` for stubbing functions (the user has seen this
  pattern at test/sdkman-test.el:300, 334-339, 423 — but never written it).
  Specifically: rebinding `(symbol-function 'message)` to capture the
  formatted output into a local list.
- **Pattern to mirror:** the existing
  `sdkman-apply-buffer-env-warns-on-missing-candidate` test
  (test/sdkman-test.el:320-339) — same `cl-letf` shape for stubbing
  `display-warning`.
- **What the test does:** construct a fake process with `make-process`
  spawning `sh -c "exit 7"` (or use `cl-letf` to fake `process-status` /
  `process-exit-status`), wait for it to die, assert the captured message
  contains "exited" and "7".

#### 5b — Stub-bash helper + happy-path test for `sdkman-sdk-current`

This is the first test that spawns a real subprocess. The pattern: drop a
shell-script `bash` into a tempdir, prepend that tempdir to `exec-path`
inside a `let`, then call the command. The real `bash` is bypassed; our
stub runs instead and we control what it writes/returns.

- **New concept 1:** `exec-path` (Emacs's own PATH for `make-process`
  command lookup) and how `let`-binding it intercepts subprocess
  resolution.
- **New concept 2:** `accept-process-output` — the explicit yield that
  lets the Emacs event loop run while a synchronous test waits for an
  async process. The idiom
  `(while (process-live-p p) (accept-process-output p 1))` plus one
  trailing `(accept-process-output nil 0.1)` to flush the sentinel.
- **New concept 3:** writing a tiny defun-helper inside the test file
  (`sdkman-test--write-stub-bash`) that takes a root dir + exit code,
  drops a stub script in `root/stub-bin/bash`, chmods it executable
  (`set-file-modes ... #o755`), and returns the directory to prepend to
  `exec-path`. Mirror style of existing
  `sdkman-test-create-candidate` (test/sdkman-test.el:140-146).
- **What the test does:** create temp ROOT, write fake
  `bin/sdkman-init.sh` (empty, just needs to be readable so
  `sdkman--init-script` succeeds), install stub bash exit 0,
  `let`-bind `sdkman-root` to ROOT and `exec-path` to include the
  stub-bin, stub `pop-to-buffer` to `#'ignore`, call
  `(sdkman-sdk-current)`, wait, assert buffer `"*sdkman: current*"`
  exists and contains the header line + stub-bash output, assert
  `major-mode` is `sdkman-process-mode`.

#### 5c — Happy-path test for `sdkman-sdk-list`

Same shape as 5b but with a candidate present (so `directory-files`
in the interactive form has something to read) and an SDK arg passed
in. Buffer name template uses `format` so verify it lands in
`"*sdkman: list java*"` specifically.

- **No new concept** — exercises the same scaffolding as 5b. Goal here
  is to confirm the SDK-argument flow and the formatted buffer name
  work.

#### 5d — Missing-root error path

The cheapest test. `let`-bind `sdkman-root` to a path that doesn't
exist, call `(sdkman-sdk-list "java")` (or current), assert
`should-error` with `:type 'user-error`.

- **No new concept** — mirrors existing
  `sdkman--ensure-root-signals-user-error-for-missing-root` test
  (test/sdkman-test.el:361-363).

#### Verify after each sub-step

```sh
emacs --batch -Q -L . -l test/sdkman-test.el -f ert-run-tests-batch-and-exit
```

Test count should rise from 39 → 40 → 41 → 42 → 43. All green.

### Step 6 — README.md

- Lines 93-102 (Transient menu): add two bullets for `L` and `C`.
- Lines 144-161 (Roadmap): replace the "Asynchronous `sdk` CLI wrapper"
  bullet with one narrowed to the remaining mutating subcommands
  (install/uninstall/default/upgrade/selfupdate), so `list` and `current`
  are no longer promised.

### Step 7 — Version bump

- `sdkman.el` header `;; Version: 0.2.0` → `0.3.0`.
- After quality gate green: `git tag v0.3.0`.

### Step 8 — Primer update (docs/elisp-primer.md)

Append four short modules using the same format as the existing 20:

- **Module 21 — `define-derived-mode`**: anchor to `sdkman-process-mode`;
  show how inheriting from `compilation-mode` gives `q` and navigation for
  free; exercise: derive a mode of your own from `special-mode`.
- **Module 22 — Process sentinels**: anchor to `sdkman--process-sentinel`;
  signature, `event` string forms, `process-status` symbols; exercise: add
  a "success" branch that messages elapsed time.
- **Module 23 — `cl-letf` for tests**: anchor to the new sentinel test;
  show the `(symbol-function 'foo)` place; warn about `letf`'s deprecation.
- **Module 24 — `accept-process-output`**: anchor to the new tests; explain
  why polling is the canonical Emacs idiom for "wait for this process".

Update `MEMORY.md` index entry for `project-sdkman.md` and the project
memory's module list once each module is published.

## Critical files

- `/Users/aqualogic/Workspace/Personal/setup/sdkman.el/sdkman.el` — add
  `sdkman-process-mode`, sentinel, `sdkman--run-cli`, two commands,
  transient bindings; bump Version header.
- `/Users/aqualogic/Workspace/Personal/setup/sdkman.el/test/sdkman-test.el`
  — add four tests; reuse `sdkman-test-with-temp-dir`,
  `sdkman-test-write-file`, `sdkman-test-mkdir`.
- `/Users/aqualogic/Workspace/Personal/setup/sdkman.el/README.md` — extend
  Transient menu section, narrow Roadmap entry.
- `/Users/aqualogic/Workspace/Personal/setup/sdkman.el/docs/elisp-primer.md`
  — append Modules 21–24.

## Reused helpers (do not duplicate)

- `sdkman--run-sdk-async` (sdkman.el:165-181) — sole entry point for
  spawning the process; pass `buf` and our new sentinel.
- `sdkman--ensure-root` (sdkman.el:142-155) — both commands use the
  explicit variant.
- `sdkman--init-script` (sdkman.el:157-163) — already called inside
  `sdkman--run-sdk-async`; no direct use here.
- `sdkman-test-with-temp-dir` / `-write-file` / `-mkdir`
  (test/sdkman-test.el:8-25) — all four new tests build on these.
- Existing command shape from `sdkman-show-env` (sdkman.el:491-504) and
  `sdkman-show-installed` (sdkman.el:507-525) — `with-current-buffer` +
  `inhibit-read-only` + `pop-to-buffer` template.

## Out of scope (do not start)

- Phase 0 task 1: expanding `sdkman-known-env-vars` further. Memory says
  it was completed in commit `35b0886`; verify before any edit, but no
  Phase 2 work needed.
- Mutating `sdk` subcommands (`install`, `uninstall`, `default`,
  `upgrade`, `selfupdate`) — Phase 5, gated on `yes-or-no-p`.
- `.sdkmanrc` writer / project switching — Phase 3.
- Explicit LSP restart — Phase 4.
- MELPA recipe, CI workflow, CHANGELOG — Phase 6.

## Verification

From the repo root, run the standard quality gate before declaring done:

```sh
emacs --batch -Q -L . -l test/sdkman-test.el -f ert-run-tests-batch-and-exit
emacs --batch -Q -L . -f batch-byte-compile sdkman.el && rm sdkman.elc
emacs --batch -Q -L . --eval "(progn (require 'checkdoc) (checkdoc-file \"sdkman.el\"))"
emacs --batch -Q --eval "(progn (require 'package) (package-initialize))" \
  -L . --eval "(require 'package-lint)" \
  -f package-lint-batch-and-exit sdkman.el
```

Manual smoke (in a GUI Emacs with SDKMAN installed):

1. Open a buffer under a project with `.sdkmanrc`. `M-x sdkman`.
2. Press `L`, pick `java`. Expect `*sdkman: list java*` with live `sdk
   list` output, header line `$ sdk list java`, mode line shows `SDKMAN`.
3. Press `q`. Buffer buries (inherited from `compilation-mode`).
4. `M-x sdkman` → `C`. Expect `*sdkman: current*` showing current versions.
5. Failure path: `let`-bind `sdkman-root` to a bogus directory, run `L`.
   Expect `user-error: SDKMAN root not found: …`.

Then commit per phase, bump tag, and append the four primer modules.
